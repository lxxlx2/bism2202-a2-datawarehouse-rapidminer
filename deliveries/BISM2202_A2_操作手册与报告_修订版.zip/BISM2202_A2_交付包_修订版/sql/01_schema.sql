/* 第三版 original schema variant: separate destination/origin geography + status dimension.
   Execute on ISOLATED Windows SQL Server 2022 instance. Abort if existing target. */
USE master;
GO
IF DB_ID(N'BISM2202_A2_dw') IS NOT NULL
    THROW 51001, 'Refusing to overwrite existing BISM2202_A2_dw. Restore or rename explicitly.', 1;
GO
CREATE DATABASE [BISM2202_A2_dw];
GO
USE [BISM2202_A2_dw];
GO
SET XACT_ABORT ON;
CREATE TABLE dbo.RefAge ([Age_Id] NVARCHAR(256), [Age] NVARCHAR(256));
CREATE TABLE dbo.RefEducation ([EDU_ID] NVARCHAR(256), [Education_level] NVARCHAR(256));
CREATE TABLE dbo.RefState ([state_name] NVARCHAR(256), [state_code] NVARCHAR(256));
CREATE TABLE dbo.RefSellerLocation (
 [location_id] NVARCHAR(256), [unit] NVARCHAR(256), [street] NVARCHAR(256),
 [postcode] NVARCHAR(256), [suburb] NVARCHAR(256), [state] NVARCHAR(256),
 [type] NVARCHAR(256), [status] NVARCHAR(256), [region] NVARCHAR(256)
);
CREATE TABLE dbo.DimSeller (
 SellerKey INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 SellerID NVARCHAR(64) NOT NULL UNIQUE,
 SellerName NVARCHAR(256), SellerLocationID NVARCHAR(64) NOT NULL,
 CreatedAt DATETIME2 NULL, EndAt NVARCHAR(100) NULL
);
CREATE TABLE dbo.DimCustomer (
 CustomerKey INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 CustomerID NVARCHAR(64) NOT NULL UNIQUE,
 Gender NVARCHAR(32) NULL, Age SMALLINT NOT NULL,
 AgeSourceKey NVARCHAR(32) NOT NULL, EducationSourceCode NVARCHAR(32) NOT NULL,
 EducationCode NVARCHAR(32) NOT NULL, EducationLevel NVARCHAR(128) NOT NULL,
 CustomerLocationID NVARCHAR(64) NOT NULL,
 CONSTRAINT C_CheckCustomerAge CHECK (Age BETWEEN 0 AND 120)
);
CREATE TABLE dbo.DimProduct (
 ProductKey INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 ProductID NVARCHAR(64) NOT NULL UNIQUE, ProductName NVARCHAR(1024),
 SubcategoryID NVARCHAR(64) NOT NULL, SubcategoryName NVARCHAR(256) NOT NULL,
 CategoryID NVARCHAR(64) NOT NULL,CategoryName NVARCHAR(256) NOT NULL
);
CREATE TABLE dbo.DimDate (
 DateKey INT NOT NULL PRIMARY KEY, CalendarDate DATE NOT NULL UNIQUE,
 CalendarYear SMALLINT NOT NULL, CalendarQuarter TINYINT NOT NULL,
 CalendarMonth TINYINT NOT NULL, DayOfMonth TINYINT NOT NULL
);
CREATE TABLE dbo.DimCustomerGeography (
 CustomerGeographyKey INT IDENTITY(1,1) PRIMARY KEY,
 LocationID NVARCHAR(64) NOT NULL UNIQUE, Postcode NVARCHAR(16), Suburb NVARCHAR(256),
 StateCode NVARCHAR(3) NOT NULL, StateName NVARCHAR(64) NOT NULL,
 RegionCode NVARCHAR(16), LocationType NVARCHAR(32), LocationConflict BIT NOT NULL
);
CREATE TABLE dbo.DimSellerGeography (
 SellerGeographyKey INT IDENTITY(1,1) PRIMARY KEY,
 LocationID NVARCHAR(64) NOT NULL UNIQUE, Postcode NVARCHAR(16), Suburb NVARCHAR(256),
 StateCode NVARCHAR(3) NOT NULL, StateName NVARCHAR(64) NOT NULL,
 RegionCode NVARCHAR(16), LocationType NVARCHAR(32),LocationConflict BIT NOT NULL,
 CONSTRAINT C_SellerState CHECK (StateCode IN ('ACT','NSW','NT','QLD','SA','TAS','VIC','WA','UNK'))
);
CREATE TABLE dbo.DimOrderStatus (
 StatusKey SMALLINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 StatusCode NVARCHAR(32) NOT NULL UNIQUE
);
CREATE TABLE dbo.FactOrderItem (
 SalesKey BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 OrderItemID NVARCHAR(64) NOT NULL UNIQUE,
 OrderID NVARCHAR(64) NOT NULL, ItemSequence INT NULL,
 CustomerKey INT NOT NULL REFERENCES dbo.DimCustomer(CustomerKey),
 ProductKey INT NOT NULL REFERENCES dbo.DimProduct(ProductKey),
 SellerKey INT NOT NULL REFERENCES dbo.DimSeller(SellerKey),
 PurchaseDateKey INT NOT NULL REFERENCES dbo.DimDate(DateKey),
 CustomerGeographyKey INT NOT NULL REFERENCES dbo.DimCustomerGeography(CustomerGeographyKey),
 SellerGeographyKey INT NOT NULL REFERENCES dbo.DimSellerGeography(SellerGeographyKey),
 StatusKey SMALLINT NOT NULL REFERENCES dbo.DimOrderStatus(StatusKey),
 ItemQuantity INT NOT NULL,
 SourceUnitSalesPrice FLOAT NOT NULL, SourceLineTotal FLOAT NOT NULL,
 UnitSalesPrice DECIMAL(19,4) NOT NULL,LineAmount DECIMAL(19,4) NOT NULL,
 ExtendedAmount DECIMAL(19,4) NOT NULL,AmountDifference DECIMAL(19,4) NOT NULL,
 FreightAmount DECIMAL(19,4) NULL,
 CONSTRAINT C_QuantityPositive CHECK (ItemQuantity > 0)
);
CREATE INDEX IX_C_SalesState ON dbo.FactOrderItem(CustomerGeographyKey,PurchaseDateKey) INCLUDE (StatusKey,ItemQuantity,LineAmount,CustomerKey,ProductKey);
CREATE INDEX IX_C_SalesSeller ON dbo.FactOrderItem(SellerGeographyKey,PurchaseDateKey) INCLUDE (StatusKey,ItemQuantity,LineAmount,SellerKey);
