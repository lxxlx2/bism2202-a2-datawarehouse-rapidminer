/* Three mandatory teacher questions, 第三版 independent query construction.
   Run after SSIS has loaded all dimensions/facts; result values are NOT supplied. */
USE [BISM2202_A2_dw];
GO
SET NOCOUNT ON;

/* Q4.1: Exact customer age yielding highest delivered line revenue by customer destination state.
   Include count of distinct customers to contextualize large-cohort effects.
   TOP (1) WITH TIES may yield more than one age per state. */
WITH state_age_sales AS (
    SELECT cg.StateCode, c.Age,
           SUM(f.LineAmount) AS Revenue,
           COUNT_BIG(*) AS OrderItemCount,
           COUNT(DISTINCT c.CustomerID) AS UniqueCustomers
    FROM dbo.FactOrderItem f
    JOIN dbo.DimCustomer c ON c.CustomerKey=f.CustomerKey
    JOIN dbo.DimCustomerGeography cg ON cg.CustomerGeographyKey=f.CustomerGeographyKey
    JOIN dbo.DimOrderStatus os ON os.StatusKey=f.StatusKey
    WHERE os.StatusCode=N'delivered' AND c.Age IS NOT NULL AND cg.StateCode IS NOT NULL
    GROUP BY cg.StateCode,c.Age
)
SELECT s.StateCode, best.Age, best.Revenue, best.OrderItemCount,
       best.UniqueCustomers,
       CAST(best.Revenue/NULLIF(best.UniqueCustomers,0) AS DECIMAL(19,4)) AS RevenuePerUniqueCustomer
FROM (SELECT DISTINCT StateCode FROM state_age_sales) s
CROSS APPLY (
    SELECT TOP (1) WITH TIES a.Age,a.Revenue,a.OrderItemCount,a.UniqueCustomers
    FROM state_age_sales a WHERE a.StateCode=s.StateCode
    ORDER BY a.Revenue DESC
) best
ORDER BY s.StateCode,best.Age;
GO

/* Q4.2: Exactly five product CATEGORIES by delivered unit volume, in each destination state.
   Revenue supports context; category ID is a deterministic tie breaker. */
WITH state_category AS (
    SELECT cg.StateCode, p.CategoryID, p.CategoryName,
           SUM(CONVERT(BIGINT,f.ItemQuantity)) AS UnitsSold,
           SUM(f.LineAmount) AS Revenue,
           COUNT_BIG(*) AS ItemRows
    FROM dbo.FactOrderItem f
    JOIN dbo.DimCustomerGeography cg ON cg.CustomerGeographyKey=f.CustomerGeographyKey
    JOIN dbo.DimProduct p ON p.ProductKey=f.ProductKey
    JOIN dbo.DimOrderStatus os ON os.StatusKey=f.StatusKey
    WHERE os.StatusCode=N'delivered' AND cg.StateCode IS NOT NULL
    GROUP BY cg.StateCode,p.CategoryID,p.CategoryName
)
SELECT states.StateCode, topcat.CategoryID, topcat.CategoryName,
       topcat.UnitsSold, topcat.Revenue, topcat.ItemRows
FROM (SELECT DISTINCT StateCode FROM state_category) states
CROSS APPLY (
    SELECT TOP (5) a.CategoryID,a.CategoryName,a.UnitsSold,a.Revenue,a.ItemRows
    FROM state_category a WHERE a.StateCode=states.StateCode
    ORDER BY a.UnitsSold DESC,a.CategoryID ASC
) topcat
ORDER BY states.StateCode,topcat.UnitsSold DESC,topcat.CategoryID;
GO

/* Q4.3: Five NSW-origin sellers by item quantity in each purchase year.
   Do not use NSW destination or resolve conflicting geography by guessing.
   Annual change is supplemental and compares the SAME seller in consecutive years. */
WITH seller_year AS (
    SELECT d.CalendarYear,s.SellerID,s.SellerName,
           SUM(CONVERT(BIGINT,f.ItemQuantity)) AS UnitsSold,
           SUM(f.LineAmount) AS Revenue,
           COUNT_BIG(*) AS ItemRows
    FROM dbo.FactOrderItem f
    JOIN dbo.DimDate d ON d.DateKey=f.PurchaseDateKey
    JOIN dbo.DimSeller s ON s.SellerKey=f.SellerKey
    JOIN dbo.DimSellerGeography sg ON sg.SellerGeographyKey=f.SellerGeographyKey
    JOIN dbo.DimOrderStatus os ON os.StatusKey=f.StatusKey
    WHERE os.StatusCode=N'delivered'
      AND sg.StateCode=N'NSW' AND sg.LocationConflict=0
    GROUP BY d.CalendarYear,s.SellerID,s.SellerName
)
SELECT years.CalendarYear, leaders.SellerID,leaders.SellerName,
       leaders.UnitsSold,leaders.Revenue,leaders.ItemRows,
       prev.UnitsSold AS PreviousYearUnits,
       CASE WHEN prev.UnitsSold IS NOT NULL AND prev.UnitsSold>0
            THEN CAST((leaders.UnitsSold-prev.UnitsSold)*100.0/prev.UnitsSold AS DECIMAL(14,2))
            ELSE NULL END AS YearOnYearPercent
FROM (SELECT DISTINCT CalendarYear FROM seller_year) years
CROSS APPLY (
    SELECT TOP (5) sy.SellerID,sy.SellerName,sy.UnitsSold,sy.Revenue,sy.ItemRows
    FROM seller_year sy WHERE sy.CalendarYear=years.CalendarYear
    ORDER BY sy.UnitsSold DESC,sy.SellerID ASC
) leaders
LEFT JOIN seller_year prev
 ON prev.CalendarYear=years.CalendarYear-1 AND prev.SellerID=leaders.SellerID
ORDER BY years.CalendarYear,leaders.UnitsSold DESC,leaders.SellerID;
GO
