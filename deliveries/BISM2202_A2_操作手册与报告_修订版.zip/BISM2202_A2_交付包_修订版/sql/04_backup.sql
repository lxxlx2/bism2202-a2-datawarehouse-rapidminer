/* Run in SSMS AFTER SSIS and 03_validation pass; create C:\BISM2202\deliveries in Explorer first. */
USE master;
GO
IF DB_ID(N'BISM2202_A2_dw') IS NULL
  THROW 51021, '第三版 warehouse missing', 1;
GO
BACKUP DATABASE [BISM2202_A2_dw]
TO DISK=N'C:\BISM2202\deliveries\BISM2202_A2_dw.bak'
WITH COPY_ONLY, INIT, CHECKSUM, STATS=10;
GO
RESTORE VERIFYONLY
FROM DISK=N'C:\BISM2202\deliveries\BISM2202_A2_dw.bak'
WITH CHECKSUM;
GO
RESTORE FILELISTONLY
FROM DISK=N'C:\BISM2202\deliveries\BISM2202_A2_dw.bak';
GO
/* VERIFYONLY is insufficient to prove restore. Use SSMS Restore Database to a NEW
   name BISM2202_A2_RESTORE_QA and a NEW pair of data/log file paths. Then run 03_validation
   against the restored database, after editing USE there. Never restore over source. */
