/* Read-only final reconciliation, execute only after native SSIS actual success. */
USE [BISM2202_A2_dw];
GO
SELECT 'RefAge' TableName,COUNT_BIG(*) Rows FROM dbo.RefAge UNION ALL
SELECT 'RefEducation',COUNT_BIG(*) FROM dbo.RefEducation UNION ALL
SELECT 'RefState',COUNT_BIG(*) FROM dbo.RefState UNION ALL
SELECT 'RefSellerLocation',COUNT_BIG(*) FROM dbo.RefSellerLocation UNION ALL
SELECT 'DimCustomer',COUNT_BIG(*) FROM dbo.DimCustomer UNION ALL
SELECT 'DimProduct',COUNT_BIG(*) FROM dbo.DimProduct UNION ALL
SELECT 'DimSeller',COUNT_BIG(*) FROM dbo.DimSeller UNION ALL
SELECT 'DimDate',COUNT_BIG(*) FROM dbo.DimDate UNION ALL
SELECT 'DimCustomerGeography',COUNT_BIG(*) FROM dbo.DimCustomerGeography UNION ALL
SELECT 'DimSellerGeography',COUNT_BIG(*) FROM dbo.DimSellerGeography UNION ALL
SELECT 'DimOrderStatus',COUNT_BIG(*) FROM dbo.DimOrderStatus UNION ALL
SELECT 'FactOrderItem',COUNT_BIG(*) FROM dbo.FactOrderItem;
GO
SELECT SUM(CAST(ItemQuantity AS BIGINT)) AS AllStatusUnits,
SUM(CASE WHEN os.StatusCode=N'delivered' THEN LineAmount ELSE CAST(0 AS DECIMAL(19,4)) END) AS DeliveredRevenueProxy,
COUNT(DISTINCT OrderItemID) AS UniqueItems
FROM dbo.FactOrderItem f JOIN dbo.DimOrderStatus os ON f.StatusKey=os.StatusKey;
GO
SELECT StatusCode,COUNT_BIG(*) AS FactRows
FROM dbo.FactOrderItem f JOIN dbo.DimOrderStatus os ON f.StatusKey=os.StatusKey
GROUP BY StatusCode ORDER BY StatusCode;
GO
SELECT COUNT_BIG(*) AS OrphanedStatus
FROM dbo.FactOrderItem f LEFT JOIN dbo.DimOrderStatus d ON d.StatusKey=f.StatusKey
WHERE d.StatusKey IS NULL;
GO
SELECT LocationID,StateCode,LocationConflict FROM dbo.DimSellerGeography WHERE LocationConflict=1;
GO
/* Source reconciliation, when original ozmart_db is installed */
SELECT (SELECT COUNT_BIG(*) FROM ozmart_db.dbo.order_items_table) AS OriginalItems,
       (SELECT COUNT_BIG(*) FROM dbo.FactOrderItem) AS WarehouseItems,
       (SELECT SUM(CONVERT(BIGINT,item_quantity)) FROM ozmart_db.dbo.order_items_table) AS OriginalUnits,
       (SELECT SUM(CONVERT(BIGINT,ItemQuantity)) FROM dbo.FactOrderItem) AS WarehouseUnits;
