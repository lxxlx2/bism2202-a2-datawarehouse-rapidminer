#!/usr/bin/env python3
"""Generate RapidMiner 12.1-compatible native XML processes (source preparation only).
Run outputs in the official GUI to establish compatibility and true results.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import csv
import argparse
import copy

HERE = Path(__file__).resolve().parents[1]
VER = '12.1.001'
SOURCE = 'data/BISM2202_A2_Loan_Data_Set_RapidMiner2026S2.csv'
COLS = ['Customer_id','Age','Work_class','Loan_amount','Education','Years_of_education','Marital_status','Occupation','Race','Gender','State','Capital_gain','Capital_loss','Weekly_work_hours','Country/area_of_origin','Income','Current_mortgage','Student_debt','Number_of_homes_owned','Bank_balance','Loan_purpose','Credit_history','Past_bankruptcy','Loan_defaulted']
NOM = {'Customer_id','Work_class','Education','Marital_status','Occupation','Race','Gender','State','Country/area_of_origin','Income','Loan_purpose'}
INT = {'Age','Years_of_education','Capital_gain','Capital_loss','Weekly_work_hours','Current_mortgage','Student_debt','Number_of_homes_owned','Past_bankruptcy','Loan_defaulted'}
FEATURES = ['Age','Loan_amount','Income','Current_mortgage','Student_debt','Bank_balance','Capital_gain','Capital_loss','Loan_purpose','Credit_history','Past_bankruptcy']

def operator(parent, typ, name, params=None, x=45,y=45):
    t=ET.SubElement(parent,'operator',{'activated':'true','class':typ,'compatibility':VER,'expanded':'true','height':'68','name':name,'width':'90','x':str(x),'y':str(y)})
    for k,v in (params or {}).items():ET.SubElement(t,'parameter',{'key':k,'value':str(v)})
    return t

def conn(parent,src,src_port,dst,dst_port):
    attrib={'from_port':src_port,'to_port':dst_port}
    if src:attrib['from_op']=src
    if dst:attrib['to_op']=dst
    ET.SubElement(parent,'connect',attrib)

def performance(parent,name,x=45,y=45):
    return operator(parent,'performance_binominal_classification',name,{'manually_set_positive_class':'true','positive_class':'true','main_criterion':'f_measure','accuracy':'true','precision':'true','recall':'true','f_measure':'true','AUC':'true','false_positive':'true','false_negative':'true','true_positive':'true','true_negative':'true'},x,y)

def context():
    root=ET.Element('process',{'version':VER})
    ct=ET.SubElement(root,'context');ET.SubElement(ct,'input');ET.SubElement(ct,'output')
    mm=ET.SubElement(ct,'macros');m=ET.SubElement(mm,'macro');ET.SubElement(m,'key').text='source_csv';ET.SubElement(m,'value').text=SOURCE
    p=operator(root,'process','Process',{'logverbosity':'init','random_seed':'73421','send_mail':'never'})
    return root,ET.SubElement(p,'process',{'expanded':'true'})

def build(model,mode):
    root,top=context()
    read=operator(top,'read_csv','Read Teacher Loan CSV',{'csv_file':'%{source_csv}','column_separators':',','encoding':'windows-1252','use_header_row':'true','read_not_matching_values_as_missings':'true','read_all_values_as_polynominal':'false'},45)
    mt=ET.SubElement(read,'list',{'key':'data_set_meta_data_information'})
    for i,col in enumerate(COLS):
        dtype='polynominal' if col in NOM else 'integer' if col in INT else 'real'
        ET.SubElement(mt,'parameter',{'key':str(i),'value':f'{col}.true.{dtype}.attribute'})
    operator(top,'set_role','Set Label',{'attribute_name':'Loan_defaulted','target_role':'label'},180)
    operator(top,'set_role','Set ID',{'attribute_name':'Customer_id','target_role':'id'},315)
    operator(top,'filter_examples','Remove Unknown Outcomes',{'condition_class':'no_missing_labels'},450)
    operator(top,'numerical_to_binominal','Map Loan Default To Boolean',{'attribute_filter_type':'single','attribute':'Loan_defaulted','include_special_attributes':'true','min':'0.0','max':'0.0'},585)
    operator(top,'select_attributes','Select Risk Predictors',{'attribute_filter_type':'subset','attributes':'|'.join(FEATURES),'include_special_attributes':'false'},720)
    chain=['Read Teacher Loan CSV','Set Label','Set ID','Remove Unknown Outcomes','Map Loan Default To Boolean','Select Risk Predictors']
    conn(top,chain[0],'output',chain[1],'example set input')
    for a,b in zip(chain[1:],chain[2:]):conn(top,a,'example set output',b,'example set input')
    s=operator(top,'split_data','75-25 Stratified Split',{'sampling_type':'stratified sampling','use_local_random_seed':'true','local_random_seed':'73421'},855)
    partitions=ET.SubElement(s,'enumeration',{'key':'partitions'})
    for value in ('0.75','0.25'):ET.SubElement(partitions,'parameter',{'key':'ratio','value':value})
    conn(top,chain[-1],'example set output','75-25 Stratified Split','example set')
    cv=operator(top,'x_validation','Five-Fold Training CV',{'number_of_validations':'5','sampling_type':'stratified sampling','use_local_random_seed':'true','local_random_seed':'74219','create_complete_model':'true'},990)
    conn(top,'75-25 Stratified Split','partition 1','Five-Fold Training CV','training')
    tr=ET.SubElement(cv,'process',{'expanded':'true'})
    operator(tr,'replace_missing_values','Training Fold Imputation',{'return_preprocessing_model':'true','attribute_filter_type':'all','default':'average'},45)
    operator(tr,'remove_unused_values','Training Fold Vocabulary',{'return_preprocessing_model':'true','attribute_filter_type':'all','include_special_attributes':'false'},180)
    conn(tr,None,'training','Training Fold Imputation','example set input')
    conn(tr,'Training Fold Imputation','example set output','Training Fold Vocabulary','example set input')
    if model=='nb':
        learner='naive_bayes';p={'laplace_correction':'true'}
    elif model=='gbt':
        learner='h2o:gradient_boosted_trees';p={'number_of_trees':'60','maximal_depth':'4','learning_rate':'0.06','reproducible':'true','maximum_number_of_threads':'1','use_local_random_seed':'true','local_random_seed':'73421'}
    else:raise ValueError(model)
    operator(tr,learner,'Train '+model.upper(),p,315)
    conn(tr,'Training Fold Vocabulary','example set output','Train '+model.upper(),'training set')
    operator(tr,'group_models','Fitted Imputation Vocabulary and Model',None,450)
    conn(tr,'Training Fold Imputation','preprocessing model','Fitted Imputation Vocabulary and Model','models in 1')
    conn(tr,'Training Fold Vocabulary','preprocessing model','Fitted Imputation Vocabulary and Model','models in 2')
    conn(tr,'Train '+model.upper(),'model','Fitted Imputation Vocabulary and Model','models in 3')
    conn(tr,'Fitted Imputation Vocabulary and Model','model out',None,'model')
    test=ET.SubElement(cv,'process',{'expanded':'true'})
    operator(test,'apply_model','Apply Fold Model',None,45)
    performance(test,'Evaluate Folds',180)
    conn(test,None,'model','Apply Fold Model','model')
    conn(test,None,'test set','Apply Fold Model','unlabelled data')
    conn(test,'Apply Fold Model','labelled data','Evaluate Folds','labelled data')
    conn(test,'Evaluate Folds','performance',None,'averagable 1')
    conn(top,'Five-Fold Training CV','averagable 1',None,'result 1')
    if mode=='holdout':
        operator(top,'apply_model','Apply Frozen Holdout',None,1125,160)
        performance(top,'Evaluate Untouched Holdout',1260,160)
        conn(top,'Five-Fold Training CV','model','Apply Frozen Holdout','model')
        conn(top,'75-25 Stratified Split','partition 2','Apply Frozen Holdout','unlabelled data')
        conn(top,'Apply Frozen Holdout','labelled data','Evaluate Untouched Holdout','labelled data')
        conn(top,'Evaluate Untouched Holdout','performance',None,'result 2')
        conn(top,'Evaluate Untouched Holdout','example set',None,'result 3')
        conn(top,'Five-Fold Training CV','model',None,'result 4')
    elif mode=='cv':
        conn(top,'Five-Fold Training CV','model',None,'result 2')
    else:raise ValueError(mode)
    return root

def lint(root):
    for block in root.iter('process'):
        if block is root:continue
        ops=[n.get('name') for n in block.findall('operator')]
        if len(ops)!=len(set(ops)):raise ValueError('Duplicate operator name')
        for cn in block.findall('connect'):
            for a in ('from_op','to_op'):
                if cn.get(a) and cn.get(a) not in ops:raise ValueError('Dangling '+a+': '+cn.get(a))

def main():
    out=HERE/'rapidminer'
    for m in ('nb','gbt'):
        for mode in ('cv','holdout'):
            root=build(m,mode);lint(root)
            tree=ET.ElementTree(root);ET.indent(tree,space='  ')
            p=out/(('NaiveBayes' if m=='nb' else 'GradientBoostedTrees')+'_'+('CV' if mode=='cv' else 'Full')+'.rmp');tree.write(p,encoding='utf-8',xml_declaration=True)
            ET.parse(p)
            print('XML_OK',p.name,p.stat().st_size)
    mainroot,combined=context()
    for branch_i,model in enumerate(('nb','gbt')):
        source=build(model,'holdout')
        process=source.find('operator/process')
        rename={node.get('name'):model.upper()+' '+node.get('name') for node in process.findall('operator')}
        for node in list(process):
            imported=copy.deepcopy(node)
            for el in [imported]+list(imported.iter()):
                if el.tag=='operator' and el.get('name') in rename:
                    el.set('name',rename[el.get('name')])
                    if el is imported:el.set('y',str(int(el.get('y','45'))+branch_i*400))
                if el.tag=='connect':
                    for key in ('from_op','to_op'):
                        if el.get(key) in rename:el.set(key,rename[el.get(key)])
                    if el.get('to_op') is None and el.get('to_port','').startswith('result '):
                        number=int(el.get('to_port').split()[1])+4*branch_i
                        el.set('to_port','result '+str(number))
            combined.append(imported)
    lint(mainroot)
    tree=ET.ElementTree(mainroot);ET.indent(tree,space='  ')
    p=out/'BISM2202_A2_rapidminer.rmp';tree.write(p,encoding='utf-8',xml_declaration=True)
    ET.parse(p)
    print('XML_OK',p.name,p.stat().st_size)
if __name__=='__main__':main()
