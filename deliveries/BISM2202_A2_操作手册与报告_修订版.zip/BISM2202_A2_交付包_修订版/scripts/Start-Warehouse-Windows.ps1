$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$workspace = 'C:\BISM2202\assignment_work\csv'
$csv = Join-Path $root 'ssis\Support\csv'
$generator = Join-Path $root 'ssis\BISM2202_A2_SSIS\Run-Warehouse.ps1'
$files = @('Age_Table.csv','Customer_Education.csv','State_code.csv','seller_location.csv')
if (-not (Test-Path $generator)) { throw 'Run scripts/generate_warehouse_windows.py on the Mac first and transfer its generated files' }
New-Item -Force -ItemType Directory $workspace | Out-Null
foreach($file in $files) {
    $from = Join-Path $csv $file
    if (-not (Test-Path $from)) { throw "Missing teacher CSV $from" }
    Copy-Item $from (Join-Path $workspace $file) -Force
}
$c = New-Object System.Data.SqlClient.SqlConnection('Server=.;Database=master;Integrated Security=True;Encrypt=False')
try {
    $c.Open()
    foreach($name in @('ozmart_db','BISM2202_A2_dw')) {
        $cmd=$c.CreateCommand();$cmd.CommandText='SELECT DB_ID(@db)';$null=$cmd.Parameters.AddWithValue('@db',$name)
        if ($cmd.ExecuteScalar() -is [DBNull]) { throw "Missing SQL Server database $name; run original source restore or sql/01_schema.sql first" }
    }
} finally {$c.Dispose()}
Write-Host 'Running independent native SSIS data flows on local SQL Server 2022...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $generator -Student A2
if($LASTEXITCODE -ne 0) { throw "Native SSIS generator returned nonzero exit $LASTEXITCODE" }
Write-Host 'Native pipeline runner returned 0. Inspect ssis\BISM2202_A2_SSIS\warehouse_results.txt'
