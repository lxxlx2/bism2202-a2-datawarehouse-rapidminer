#!/usr/bin/env python3
"""Extract original UQ teaching assets from the separate cloned repository. No rewriting of source records."""
from pathlib import Path
import argparse,zipfile,hashlib,shutil,sys
HERE=Path(__file__).resolve().parents[1]
SHAS={
'Assginmen2_Case_BISM2202_2026s2_Business_Report.docx':'485144ccdaf745eec9ca00ab5ed239faaa6f996dd0b6f78959f0f13c8ff84def',
'A2_Rubric_DimensionalModel_RapidMiner.docx':'a9fc13b0acb53c274b94d6ab3fe7141bd81587bbe258cc2acb34e73f950c3adc',
'BISM2202_2026S2_Assignment2_RapidMiner_Package.zip':'b37546bef506005a9ffe7d48a9e2869f1aef0c5927b6ece8d5804e8a1757edd5',
'BISM2202_2026S2_Assignment2_SSIS_Package.zip':'3e1fe12009b39de3f452127d61ef59c49abff104db76b2533fa8f49d0c77adf9'}
CSV='BISM2202_A2_Loan_Data_Set_RapidMiner2026S2.csv'
LOAN_SHA='b333abef401d01dce2b0115b65649400238c01d9362b328c8ca1c4c19876d00a'
SOURCES=['Age_Table.csv','Customer_Education.csv','State_code.csv','seller_location.csv']

def checksum(data):return hashlib.sha256(data).hexdigest()
def safe_read_archive(archive,name):
    matches=[i for i in archive.infolist() if Path(i.filename).name.casefold()==name.casefold() and not i.is_dir()]
    if len(matches)!=1:raise RuntimeError(f'Expected 1 file {name} in {archive.filename}, found {len(matches)}')
    data=archive.read(matches[0]);return data

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True);parser.add_argument('--verify-only',action='store_true');a=parser.parse_args()
    src=Path(a.repo).expanduser().resolve()/'requirements'/'original'
    for name,expected in SHAS.items():
        path=src/name
        if not path.exists():raise SystemExit(f'MISSING {path}: run git lfs pull first')
        actual=checksum(path.read_bytes())
        if actual!=expected:raise SystemExit(f'HASH_FAILED {path}: expected {expected}; actual {actual}')
        print('SOURCE_HASH_PASS',name)
    if a.verify_only:return
    rapid=src/'BISM2202_2026S2_Assignment2_RapidMiner_Package.zip'
    ssis=src/'BISM2202_2026S2_Assignment2_SSIS_Package.zip'
    with zipfile.ZipFile(rapid) as z:
        b=safe_read_archive(z,CSV)
        if checksum(b)!=LOAN_SHA:raise SystemExit('Loan CSV checksum mismatch')
        dst=HERE/'rapidminer'/'data'/CSV;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
        print('LOAN_READY',dst,'SHA256',LOAN_SHA)
    dest=HERE/'ssis'/'Support'/'csv';dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ssis) as z:
        for f in SOURCES:
            data=safe_read_archive(z,f)
            if data.startswith(b'version https://git-lfs.github.com'):raise SystemExit('Nested LFS pointer '+f)
            (dest/f).write_bytes(data)
            print('SUPPORT_READY',f,len(data))
        backups=[i for i in z.infolist() if Path(i.filename).suffix.casefold()=='.bak' and not i.is_dir()]
        if len(backups)==1:
            bdir=HERE/'ssis'/'teacher_source_backup';bdir.mkdir(parents=True,exist_ok=True)
            backup=bdir/Path(backups[0].filename).name
            with z.open(backups[0]) as inp,backup.open('wb') as outf:shutil.copyfileobj(inp,outf)
            print('TEACHER_BACKUP_READY',backup,backup.stat().st_size)
        else:
            print('BACKUP_DISCOVERY_UNRESOLVED',len(backups),'Restore from original teacher archive manually')
    shutil.copy2(src/'Assginmen2_Case_BISM2202_2026s2_Business_Report.docx',HERE/'docs'/'Teacher_Report_Template_ORIGINAL.docx')
    original_project=Path(a.repo).expanduser().resolve()/'submission'/'Student_A'/'ssis'/'STUDENT_A_ID_SSIS'
    template_dest=HERE/'ssis'/'project_template';template_dest.mkdir(parents=True,exist_ok=True)
    for filename in ('STUDENT_A_ID_SSIS.dtproj','STUDENT_A_ID_SSIS.database'):
        candidate=original_project/filename
        if candidate.exists():shutil.copy2(candidate,template_dest/filename)
        else:print('PROJECT_TEMPLATE_MISSING',filename)
    print('TEACHER_DATA_PREPARED=PASS')
if __name__=='__main__':main()
