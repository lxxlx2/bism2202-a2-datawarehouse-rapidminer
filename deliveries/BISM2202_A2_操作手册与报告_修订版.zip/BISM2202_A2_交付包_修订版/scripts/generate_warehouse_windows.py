#!/usr/bin/env python3
"""Produce a 第三版 native SSIS builder and runner from the repository's validated SQL Server 2022 SDK adapter.
DOES NOT execute Windows native SSIS; that is the school/Windows workstation stage.
All source data stays teacher-original. Source adapters are derived from the repo's audited working C#.
"""
from pathlib import Path
import argparse,re,shutil
ROOT=Path(__file__).resolve().parents[1]

def swap(s,old,new):
    n=s.count(old)
    if n!=1:raise RuntimeError(f'Patch anchor expected exactly once, saw {n}: {old[:140]}')
    return s.replace(old,new,1)

def replace_method(s,heading,new_method):
    start=s.find(heading)
    if start<0:raise ValueError(f'Method not found: {heading}')
    begin=s.find('{',start);depth=0
    for i in range(begin,len(s)):
        if s[i]=='{':depth+=1
        elif s[i]=='}':
            depth-=1
            if depth==0:
                return s[:start]+new_method+s[i+1:]
    raise ValueError('Mismatched source method braces')

def patch_cs(src):
    t=src
    t=swap(t,'public class BismCustomerFlow {','public class BismWarehousePipeline {')
    t=t.replace('BismCustomerFlow','BismWarehousePipeline')
    t=swap(t,'if(student!="A" && student!="B")','if(student!="A2")')
    # The only permitted reset is scoped to the isolated assignment database.
    t=swap(t,'string expected="STUDENT_"+student+"_ID_dw";', 'string expected="BISM2202_A2_dw";')
    t=t.replace('"Student_"+student+', '"BISM2202_"+student+')
    start='  reset.Properties["SqlStatementSource"].SetValue(reset,'
    match=re.search(r'  reset\.Properties\["SqlStatementSource"\]\.SetValue\(reset,"[^\n]*"\);',t)
    if not match:raise RuntimeError('Reset pattern missing')
    sql=("IF DB_NAME() <> 'BISM2202_A2_dw' THROW 51000,'Incorrect 第三版 destination',1; "
         "SET XACT_ABORT ON; BEGIN TRAN; "
         "DELETE FROM dbo.FactOrderItem; DELETE FROM dbo.DimCustomer; DELETE FROM dbo.DimProduct; DELETE FROM dbo.DimSeller; "
         "DELETE FROM dbo.DimDate; DELETE FROM dbo.DimCustomerGeography; DELETE FROM dbo.DimSellerGeography; "
         "DELETE FROM dbo.DimOrderStatus; DELETE FROM dbo.RefAge; DELETE FROM dbo.RefEducation; DELETE FROM dbo.RefState; "
         "DELETE FROM dbo.RefSellerLocation; COMMIT;")
    t=t[:match.start()]+f'  reset.Properties["SqlStatementSource"].SetValue(reset,"{sql}");'+t[match.end():]
    # New dependency order: four teacher lookup files, customer/product/seller, two distinct geography roles,
    # a separate order status dimension and the full-grain fact.
    t=swap(t,'Execute(source,target,"",student);Product(source,target,"",student);Geography(source,target,"",student,false);Geography(source,target,"",student,true);Date(source,target,"",student);Fact(source,target,"",student);',
             'Execute(source,target,"",student);Product(source,target,"",student);Geography(source,target,"",student,false);Geography(source,target,"",student,true);Date(source,target,"",student);Status(source,target,"",student);Fact(source,target,"",student);')
    # IDENTITY keys must not be mapped into SSIS destination input columns.
    t=swap(t,'target.Name=="GeographyKey" && table=="DimGeography"',
             'target.Name=="GeographyKey" && table=="DimGeography" || target.Name=="CustomerGeographyKey" && table=="DimCustomerGeography" || target.Name=="SellerGeographyKey" && table=="DimSellerGeography" || target.Name=="StatusKey" && table=="DimOrderStatus"')
    # Two distinct geography tables. Unlike A/B, there is no GeographyRole column in either.
    t=swap(t,'  o=b.Derived(o,"GeographyRole",seller ? "\\"Seller\\"" : "\\"Customer\\"",DT.DT_WSTR,16);\n  b.Destination(o,"DimGeography");return b.Finish(path);',
       '  o=b.Derived(o,"LocationConflict",seller ? "(DT_BOOL)(LocationID==\\"ece22fa5b9e06f5b\\")" : "(DT_BOOL)0",DT.DT_BOOL,0);\n  b.Destination(o,seller ? "DimSellerGeography" : "DimCustomerGeography");return b.Finish(path);')
    # Distinct fact natural key, new status FK and resolved destination/origin geo FKs.
    t=swap(t,'  o=b.Lookup(o,"SELECT CustomerID,CustomerKey FROM dbo.DimCustomer"',
              '  o=b.Lookup(o,"SELECT StatusCode,StatusKey FROM dbo.DimOrderStatus","OrderStatus","StatusCode","StatusKey","StatusKey",false,DT.DT_I2,0);\n  o=b.Lookup(o,"SELECT CustomerID,CustomerKey FROM dbo.DimCustomer"')
    t=swap(t,'"SELECT LocationID,GeographyKey FROM dbo.DimGeography WHERE GeographyRole=\'Customer\'","CustomerLocationID","LocationID","GeographyKey","CustomerGeographyKey"',
             '"SELECT LocationID,CustomerGeographyKey FROM dbo.DimCustomerGeography","CustomerLocationID","LocationID","CustomerGeographyKey","CustomerGeographyKey"')
    t=swap(t,'"SELECT LocationID,GeographyKey FROM dbo.DimGeography WHERE GeographyRole=\'Seller\'","SellerLocationID","LocationID","GeographyKey","SellerGeographyKey"',
             '"SELECT LocationID,SellerGeographyKey FROM dbo.DimSellerGeography","SellerLocationID","LocationID","SellerGeographyKey","SellerGeographyKey"')
    t=swap(t,'  b.Destination(o,"FactSales");return b.Finish(path);','  b.Destination(o,"FactOrderItem");return b.Finish(path);')
    # Insert native SSIS status extraction; Sort removes duplicates before OLEDB Destination.
    n='''  public static long Status(string source,string target,string path,string student) {
  var b=Create(source,target,"BISM2202_"+student+"_DimOrderStatus");
  var o=b.Source("SELECT status AS StatusCode FROM dbo.orders_table");
  o=b.Sort(o,"StatusCode",true);
  b.Destination(o,"DimOrderStatus");
  return b.Finish(path);
 }
'''
    t=t.rstrip();assert t.endswith('}')
    t=t[:-1]+n+'}\n'
    return t

def patch_ps(src):
    t=swap(src,"param([ValidateSet('A','B')][string]$Student='A')","param([ValidateSet('A2')][string]$Student='A2')")
    t=swap(t,"(Join-Path $PSScriptRoot 'CustomerFlow.cs')","(Join-Path $PSScriptRoot 'WarehouseFlow.cs')")
    t=swap(t,"[BismCustomerFlow]::Warehouse(","[BismWarehousePipeline]::Warehouse(")
    t=t.replace('STUDENT_${Student}_ID_dw','BISM2202_A2_dw')
    t=t.replace('"C:\\BISM2202\\submission\\Student_$Student\\ssis\\STUDENT_${Student}_ID_SSIS"', '"$PSScriptRoot"')
    # Schema is executed by SSMS before running this script; do not feed GO batches to ExecuteScalar.
    t=swap(t,"[void](Sql ((Get-Content -Raw (Join-Path $PSScriptRoot 'schema.sql'))+\"`nSELECT 1;\"))",
             "if ((Sql \"SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='FactOrderItem'\") -ne 1){throw 'Create 第三版 database with 01_schema.sql in SSMS first'}")
    start=t.find('$expected=@{');end=t.find('\n',start)
    if start<0:raise RuntimeError('expected row map missing')
    t=t[:start]+"$expected=@{DimSeller=100;DimCustomer=21000;DimProduct=2199;DimCustomerGeography=1500;DimSellerGeography=99;DimOrderStatus=6;FactOrderItem=137901;RefAge=78;RefEducation=6;RefState=8;RefSellerLocation=100}"+t[end:]
    t=swap(t,"'SELECT SUM(CONVERT(bigint,ItemQuantity)) FROM dbo.FactSales'","'SELECT SUM(CONVERT(bigint,ItemQuantity)) FROM dbo.FactOrderItem'")
    return t

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);args=p.parse_args()
    repo=Path(args.repo).expanduser().resolve()
    source=(repo/'scripts/windows/warehouse/CustomerFlow.cs').read_text(encoding='utf-8-sig')
    ps=(repo/'scripts/windows/warehouse/load_warehouse_master.ps1').read_text(encoding='utf-8-sig')
    dest=ROOT/'ssis'/'BISM2202_A2_SSIS';dest.mkdir(parents=True,exist_ok=True)
    (dest/'WarehouseFlow.cs').write_text(patch_cs(source),encoding='utf-8')
    (dest/'Run-Warehouse.ps1').write_text(patch_ps(ps),encoding='utf-8')
    shutil.copy2(ROOT/'sql'/'01_schema.sql',dest/'01_schema.sql')
    shutil.copy2(ROOT/'sql'/'03_validation.sql',dest/'03_validation.sql')
    print('NATIVE_SSIS_BUILDER_GENERATED',dest)
    print('Run native pipeline via Windows PowerShell. XML project is saved only if SDK execution completes.')
if __name__=='__main__':main()
