#!/usr/bin/env python3
"""Source/static QA only. It NEVER claims Windows native execution success."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re,sys,ast,hashlib,json
base=Path(__file__).resolve().parents[1]
errors=[];records={}
expected=['BISM2202_A2_rapidminer.rmp','NaiveBayes_CV.rmp','NaiveBayes_Full.rmp','GradientBoostedTrees_CV.rmp','GradientBoostedTrees_Full.rmp']
for name in expected:
    p=base/'rapidminer'/name
    try:
        root=ET.parse(p).getroot()
        operators=[e.get('class') for e in root.iter('operator')]
        if 'read_csv' not in operators or 'x_validation' not in operators or 'split_data' not in operators:errors.append(name+' missing required operators')
        if 'naive_bayes' not in operators and 'h2o:gradient_boosted_trees' not in operators:errors.append(name+' missing learner')
        if name=='BISM2202_A2_rapidminer.rmp' and (operators.count('naive_bayes')!=1 or operators.count('h2o:gradient_boosted_trees')!=1):errors.append('main learner count wrong')
        for pro in root.findall('.//operator/process'):
            names=[n.get('name') for n in pro.findall('operator')]
            if len(names)!=len(set(names)):errors.append(name+' duplicate node in local process')
            for c in pro.findall('connect'):
                for a in ('from_op','to_op'):
                    if c.get(a) and c.get(a) not in names:errors.append(name+' dangling connector '+c.get(a))
        records[name]={'bytes':p.stat().st_size,'operators':len(operators),'status':'XML parsed; no native runtime check'}
    except Exception as e:errors.append(name+' '+str(e))
for path in (base/'scripts').glob('*.py'):
    try:ast.parse(path.read_text(encoding='utf-8'))
    except Exception as e:errors.append('Python syntax error '+str(path)+' '+str(e))
for f in ['01_schema.sql','02_queries.sql','03_validation.sql','04_backup.sql']:
    if not (base/'sql'/f).exists():errors.append('missing '+f)
for token in ['DimCustomerGeography','DimSellerGeography','DimOrderStatus','FactOrderItem']:
    for f in ['01_schema.sql','02_queries.sql','03_validation.sql']:
        if token not in (base/'sql'/f).read_text(encoding='utf-8'):errors.append('missing entity '+token+' '+f)
if (base/'rapidminer'/'data'/'BISM2202_A2_Loan_Data_Set_RapidMiner2026S2.csv').exists():
    print('TEACHER_CSV_PRESENT_LOCAL_ONLY; verify the exact source checksum and sharing permission')
status='STATIC_PASS' if not errors else 'STATIC_FAIL'
print(status)
for e in errors:print('ISSUE',e)
report={'status':status,'native_windows_ssis':'NOT_RUN','native_rapidminer':'NOT_RUN','database_backup':'NOT_CREATED','proof_images':'NOT_CAPTURED','errors':errors,'RMP':records}
(Path(__file__).parent/'STATIC_VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if errors:sys.exit(1)
